package cracker;

import java.io.FileInputStream;         // For reading the input files
import java.io.PrintWriter;             // For writing to the output file
import static java.lang.System.exit;    // For exiting the program when input file is not found
import static java.lang.System.setOut;

import java.util.Scanner;               // For reading the input files

public class Cryptographer
{
    char[] key;
    public Cryptographer()
    {
        key = new char[26];//empty char array of 26

        // initializes the array with - so that you can know which character never appeared
        for(int i = 0; i < 26; i++)
        {
            key[i] = '-';
        }
    }
    /**
     * Method to read file (p1)
     * @param filename = passes in the filename required
     * @return the content of the file in a string
     */
    private String readFile(String filename)
    {
        FileInputStream stream = null;
        Scanner in;
        String Text = "";
        try
        {
            if(filename.endsWith(".txt"))//if ends with.txt
            {
                stream = new FileInputStream(filename);
            }
            else
            {
                stream = new FileInputStream(filename + ".txt");
            }

            in = new Scanner(stream);

            // read everything from the file
            while(in.hasNext())
            {
                Text += in.nextLine();//text = contents of the file
            }

            in.close();
            stream.close();
        }
        catch(Exception e)
        {
            System.out.println("Error opening \"" + filename + "\"");
            System.out.println(e.getMessage());
            // Exits the program when a file cannot be read, because you cannot perform operations.
            System.out.println("Exiting program now!");
            exit(-1);
        }
        return Text;
    }
    /**
     * Recovering the ECB key
     * @param cipherFile = passing in c1
     * @param plainFile = passing in p1
     */
    public void recoverECBKey(String cipherFile, String plainFile)
    {
        // get the contents of both files
        String cipherText = readFile(cipherFile), plainText = readFile(plainFile);
        char current;//current position of the character

        for(int i = 0, s = plainText.length(); i < s; i++)
        {
            // get the current character from the plain text
            current = plainText.charAt(i);

            // if the key of current character has not been set then set it
            if(key[current - 'a'] == '-')
            {
                // if the current character was a small alphabet
                if(current >= 'a' && current <= 'z')
                {
                    key[current - 'a'] = cipherText.charAt(i);
                }
            }
        }
    }

    /**
     * Once I have the key, decipher c2
     * @param cipherFile = passing in c2
     * @param outputFile = passing in the output file
     */
    public void decipherECB(String cipherFile, String outputFile)
    {
        //reading in c2 and creating a blank text document
        String cipherText = readFile(cipherFile), plainText = "";
        boolean added;//a check function to see if c2 has been deciphered to the output file

        // loop to traverse the cipher text
        for(int i = 0, s = cipherText.length(); i < s; i++)
        {
            added = false;
            // loop to traverse key
            for(int j = 0; j < 26; j++)
            {
                // condition to find the plain text character corresponding to the current cipher text character
                if(key[j] == cipherText.charAt(i))
                {
                    added = true;
                    plainText += Character.toString((char) (j + 'a'));
                }
            }

            // if the cipher text character was not in the key, i.e, if it was a punctuation it should be added as it is.
            if(!added)
            {
                plainText += cipherText.charAt(i);
            }
        }
        // write the contents of deciphired contents to the output file
        WriteFile(outputFile, plainText);
        System.out.println(outputFile);
    }

    /**
     * Recover the CBC key
     * @param cipherFile = c1
     * @param plainFile = p1
     * @param IV = iv passed via arg
     */
    public void recoverCBCKey(String cipherFile, String plainFile, char IV)
    {
        // get the contents of both files
        String cipherText = readFile(cipherFile), plainText = readFile(plainFile);
        char pre = IV, original;
        int current;
        /*
        **** current is the calculated index, i.e, to be used in the key
        **** pre is the the previous ciphered text, required for CBC
        **** original is the current character from the plainText
        */

        if(pre < 26)//if previous ciphered text out of bounds
        {
            pre = (char)(pre + 97);//add 97 to this. Take it back to alphabet ASCII
        }

        for(int i = 0, s = plainText.length(); i < s; i++)//loop through plaintext
        {
            original = plainText.charAt(i);//setting the original position of each letter from the plaintext

            if(original >= 'a' && original <= 'z')//if its an actual letter
            {
                current = ((original - 97) + (pre - 97)) % 26;//key = current char - 97 + previous IV - 97 % 26
                pre = cipherText.charAt(i);//set the new iv for next iteration

                key[current] = cipherText.charAt(i);//add the letter to the key
            }
        }
    }

    /**
     * Deciphering the CBC
     * @param cipherFile = c2
     * @param outputFile = output file added in
     * @param IV = iv passed into arg
     */
    public void decipherCBC(String cipherFile, String outputFile, char IV)
    {
        String cipherText = readFile(cipherFile), plainText = "";
        char pre = IV, current;
        int value;
        //reading in c2
        for(int i = 0, s = cipherText.length(); i < s; i++)
        {
            current = cipherText.charAt(i);
            for (int j = 0; j < 26; j++) {
                if (key[j] == current) {
                    /*
                       add 104 in j to make it an ascii character (adding extra
                       7 to make it a multiple of 26) and then subtract pre to
                       correctly perform decryption
                    */
                    value = ((j - pre) % 26) + 97;

                    // assign value to pre for the next iteration
                    pre = (char) (current - 97);
                    // loops to bring value between a and z

                    while (value < 97) {
                        value = value + 26;
                    }
                    while (value > 122) {
                        value = value - 26;
                    }
                    plainText += ((char) value);
                }
            }
        }
        System.out.print(plainText);
        WriteFile(outputFile, plainText);
    }

    /**
     * Writing to the output file
     * @param filename = the output file needed in the args
     * @param output = the deciphered text usually which is a string
     */
    private void WriteFile(String filename, String output)
    {
        PrintWriter writer = null;
        try
        {
            if(filename.endsWith(".txt"))
            {
                writer = new PrintWriter(filename, "UTF-8");//write in alphabet
            }
            else
            {
                writer = new PrintWriter(filename + ".txt", "UTF-8");
            }

            writer.println(output);
            writer.close();
        }
        catch(Exception e)
        {
            System.out.println("Error while making output file");
            System.out.println(e.getMessage());
        }
    }

    /**
     * Method in which prints the key
     */
    public void printKey()
    {
        System.out.println("Key:");
        System.out.println(key);
        for(int i = 0, s = key.length; i < s; i++)//loop through key
        {
            System.out.println(i + " -> " + (char)(i + 'a') + " -> " + key[i]);//key will map eah

        }
    }
}
