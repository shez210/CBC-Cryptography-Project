package cracker;

public class Assignment {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String ErrorMessage =  "\nIn order to run the code in ECB mode 5 arguments are required and for it to run in CBC mode 6 arguments are required."
                    + "\nExample of argument:"
                    + "\nECB cipherFile1.txt plainFile.txt cipherFile2.txt outputFile.txt"
                    + "\nOR"
                    + "\nCBC cipherFile1.txt plainFile.txt cipherFile2.txt outputFile.txt IV"
                    + "\nHere:"
                    + "\n\"ECB\" and \"CBC\" are modes of operation."
                    + "\ncipherFile1.txt is the name of the file which will be used to find the key."
                    + "\nplainFile.txt is the corresponding original text used to find the key."
                    + "\ncipherFile2.txt is the file whose contents are to be deciphered."
                    + "\noutputFile.txt is the file in which the deciphered text of cipherFile2.txt will be stored."
                    + "\nIV is the Initialization Vector (REQUIRED for CBC \"mode\" only)";
        
        if(args.length >= 5)//if arguments is 5 or more, then proceed
        {
            String mode = args[0], c1File = args[1], p1File = args[2], c2File = args[3], outputFile = args[4];
            Cryptographer C = new Cryptographer();
            
            if(mode.equals("ECB"))//if first argument is ECB then run all ECB functions
            {
                C.recoverECBKey(c1File, p1File);
                C.printKey();
                C.decipherECB(c2File, outputFile);
            }
            else if(mode.equals("CBC"))//if first argument is CBC then run all CBC functions
            {
                if(args.length == 6)//if args == 6 in which adds the IV
                {
                    C.recoverCBCKey(c1File, p1File, (char)Integer.parseInt(args[5]));//passes in the iv which is the 6th arg
                    C.printKey();
                     C.decipherCBC(c2File, outputFile, (char)Integer.parseInt(args[5]));//passes in the iv which is the 6th arg
                }
                else
                {
                    System.err.println("Incomplete arguments to run code!\n\"ECB\" mode, six arguments are required.\n" + ErrorMessage);
                }
            }
            else
            {
                System.err.println("Invalid mode!\nPlease use either \"ECB\" or \"CBC\" mode.\n" + ErrorMessage);
            }
        }
        else
        {
            System.err.println("Incomplete arguments to run code!\n" + ErrorMessage);
        }
    }
    
}
