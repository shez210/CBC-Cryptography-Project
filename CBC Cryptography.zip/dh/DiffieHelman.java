package dh;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Base64;
import java.util.Random;

public class DiffieHelman {
    public static void main (String [] args) {
        String errorMessage = "Incomplete set of agrguments";

        Socket server;
        BufferedReader INPUT = null;
        Random random = new Random();
        if (args.length == 5) {
            try {
                server = new Socket(InetAddress.getByName(args[0]), Integer.parseInt(args[1]));
                INPUT = new BufferedReader(new InputStreamReader(server.getInputStream()));
                PrintWriter OUTPUT = new PrintWriter(server.getOutputStream(), true);

                BigInteger A, B;
                BigInteger p = new BigInteger(args[2]), g = new BigInteger(args[3]);
                int secretNumber = Integer.parseInt(args[4]);
                String input = "", sessionKey = "", DHKey, R = "", baseKey, decryptedFile = "", encryptedFile = "";
                MessageDigest messageDigest = MessageDigest.getInstance("MD5");
                byte[] digest, key;


                //A = G^A mod p
                A = ((g.pow(secretNumber)).mod(p));
                System.out.println("A = " + A );

                //send A to server
                OUTPUT.println("**DHA**" + A + "****");

                //send B to client
                String bOut = INPUT.readLine();
                System.out.println(bOut);

                //Extracting B
                B = new BigInteger(bOut.substring(7, bOut.length()- 4));
                System.out.println("B = " + B);

                //computing Shared Key (B^SecretNumber mod P)
                DHKey = B.pow(secretNumber).mod(p).toString();
                System.out.println("DH Shared Key: "+DHKey);

                //create a sample of 4 random letters
                for (int i = 0; i < 4; i++)
                {
                    R+= (char)(random.nextInt(26)+97);
                }
                System.out.println(R);

                //pad the dh key into 12 bits
                while(DHKey.length() < 12){
                    DHKey = "0" + DHKey;
                }
                System.out.println(DHKey);

                //base key concatination
                baseKey = R + DHKey;
                System.out.println("Base Key --> " + baseKey);

                //md5 hash digestion
                //messageDigest.reset();
                messageDigest.update(baseKey.getBytes());
                digest = messageDigest.digest();
                key = digest;
                System.out.println(digest);
                System.out.println(Base64.getEncoder().encodeToString(key));

                //generating session key
                sessionKey = Base64.getEncoder().encodeToString(digest);
                System.out.println("sessionKey --> "  + sessionKey.substring(0, 16));

                //send session key to server
                OUTPUT.println("**NONCE**" + R + "****");

                //request encrypted file
                OUTPUT.println("**REQ****");

                //read encrypted file
                input = INPUT.readLine();
                System.out.println("File recieved ---> " + input);

                //remove the **ENC** from le string
                input = input.substring(7, input.length()-4);
                System.out.println("Full String ---> " + input);

                //decode the encoded string
                byte[] fileDecoded = Base64.getDecoder().decode(input);
                System.out.println("File Decoded --> " + Base64.getDecoder().decode(input));

                //creating to decipher
                Cipher cipher;
                cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, 0, 16, "AES"), new IvParameterSpec(baseKey.getBytes()));

                decryptedFile = new String(cipher.doFinal(fileDecoded));
                System.out.println(decryptedFile);

                //compute md5hash of the file content
                messageDigest.reset();
                messageDigest.update(decryptedFile.substring(5).getBytes());
                digest = messageDigest.digest();
                System.out.println("MD5 hash of decrypted file EXCLUDING FILE ----> " + digest);

                //encrypting the hash with the session key
                cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, 0, 16, "AES"), new IvParameterSpec(baseKey.getBytes()));
                fileDecoded = cipher.doFinal(digest);
                System.out.println(fileDecoded);

                //encrypting the file
                encryptedFile = Base64.getEncoder().encodeToString(fileDecoded);
                OUTPUT.println("**VERIFY**" + encryptedFile+"****");

                //get verify
                input =  INPUT.readLine();
                System.out.println(input);

            }catch(Exception e){
                System.out.println(e);
            }
        }
    }

}
